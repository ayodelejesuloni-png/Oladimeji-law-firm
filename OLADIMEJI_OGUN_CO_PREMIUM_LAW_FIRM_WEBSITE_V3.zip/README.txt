OLADIMEJI OGUN & CO. — PREMIUM LAW FIRM WEBSITE V3
=======================================================

Built from the uploaded attorney-page image as the visual guide:
- Navy + gold premium legal aesthetic
- Elegant serif headings + clean sans-serif body
- Responsive desktop/tablet/mobile navigation
- Attorney team section with Principal Counsel, Senior Associate, Associate Counsel and Legal Consultants
- Practice areas, About, Contact and Consultation pages
- FAQ accordion and front-end form validation
- Floating WhatsApp contact button
- Privacy Policy and Terms pages
- SEO/meta tags and accessibility-friendly labels

FILES
-----
index.html
about.html
services.html
attorneys.html
contact.html
booking.html
privacy.html
terms.html
css/style.css
js/script.js
images/design-reference.png

IMPORTANT
---------
The consultation/contact forms are front-end demos. They do not send email until you connect a backend/form service.
The attorney portrait areas are stylized placeholders because the supplied image is a webpage design reference, not separate portrait files. Replace those portrait blocks with approved professional photos if the firm wants real people shown.
Review the Privacy Policy/Terms and all attorney biographies before publishing.
The WhatsApp link uses the phone number supplied for the firm.
